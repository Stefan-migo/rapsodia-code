# Worktree Lifecycle Specification

## Requirements

### Requirement: Sessions are durable and discoverable

The system MUST track `.cortex-sessions/`, allow sessions-only commits in main, and discover worktrees from Git's registry, not parent globbing. Cleanup MUST resolve matching session handoffs using the documented `YYYY-MM-DD-<slug>` convention. With exactly one matching handoff, it MUST archive that exact handoff; with no matching handoff, it MUST proceed normally because absence is not a failure; with multiple matches, it MUST refuse, exit non-zero, name every candidate, and remove neither the worktree nor any handoff. The archive move MUST be idempotent and MUST produce the same single archived handoff whether performed by `cortex-session` when it consumes the inbox at change creation or by `cortex worktree cleanup` at the end; it MUST NOT archive twice, duplicate, or lose the handoff. Cleanup MUST preserve untracked, non-ignored change artifacts that are their only copy, or refuse before `git worktree remove --force` with an explicit message naming every repository-relative artifact that would be lost. Byte-identical `openspec/**` content under `main/openspec/changes/archive/**` MUST report `superseded/preserved` and MUST NOT block cleanup; `.cortex-sessions/**` and `odd/**` remain governed by main-copy equality, and `odd/**` MUST NOT resolve through an archive twin because a committed task record has a delivery path. Disposable paths (`node_modules/**`, `graphify-out/**`, `.opencode/**`, `.atl/**`, `.cortex/**`) MUST remain unprotected. Cleanup MUST start from main.

(Previously: Archived byte-identical OpenSpec copies blocked cleanup; matches now resolve, actual loss refuses.)

#### Scenario: Session record survives cleanup

- GIVEN a completed session with a tracked record and handoff `ready-for-odd/2026-09-15-worktree-workflow`
- WHEN cleanup runs for slug `worktree-workflow` and its local and remote branches are removed
- THEN the record remains versioned, that exact handoff moves to `archived/2026-09-15-worktree-workflow`, and `git worktree list` omits the worktree

#### Scenario: Cleanup refuses an ambiguous handoff

- GIVEN more than one `ready-for-odd/YYYY-MM-DD-worktree-workflow` candidate exists
- WHEN cleanup runs for slug `worktree-workflow`
- THEN it exits non-zero, reports that the handoff is ambiguous and names every candidate, and removes neither the worktree nor any handoff

#### Scenario: Cleanup does not destroy an untracked only copy

- GIVEN the worktree contains an untracked change artifact such as `openspec/` and main has no other copy
- WHEN cleanup would remove that worktree
- THEN it exits non-zero, names the artifact before removal, does not run `git worktree remove --force`, and prints no `{"cleaned":true}`

#### Scenario: Archived content auto-resolves

- GIVEN untracked `openspec/changes/demo/spec.md` equals `main/openspec/changes/archive/2026-09-16-demo/spec.md` byte-for-byte
- WHEN cleanup validates
- THEN it reports `superseded/preserved` and proceeds

#### Scenario: Resolution is explicit

- GIVEN protected OpenSpec paths include a match and an unmatched path
- WHEN cleanup validates
- THEN it reports `superseded/preserved` and `loss`, and MUST NOT proceed silently

#### Scenario: Unmatched content blocks

- GIVEN protected content has no archive twin
- WHEN cleanup validates
- THEN it exits non-zero, names every offending repository-relative path, runs no removal, and prints no `{"cleaned":true}`

#### Scenario: Mixed trees resolve per path

- GIVEN some protected OpenSpec paths have twins and others lack them
- WHEN cleanup validates
- THEN matches are `superseded/preserved`, every unmatched path is named `loss`, and cleanup refuses before removal

#### Scenario: Non-canonical content refuses

- GIVEN a half-written, hand-edited, or in-progress OpenSpec file lacks a twin
- WHEN cleanup validates
- THEN it exits non-zero, names the path `loss`, and refuses before removal

#### Scenario: Nested paths match any dated archive

- GIVEN nested `openspec/**` equals a file in another dated archive
- WHEN cleanup validates
- THEN the path is `superseded/preserved` and does not block cleanup

#### Scenario: Session archives are not twins

- GIVEN untracked `.cortex-sessions/**` matches its archived copy but not main
- WHEN cleanup validates the worktree
- THEN main-copy equality governs and it refuses as `loss`

#### Scenario: ODD task records are not archive twins

- GIVEN untracked `odd/tasks/example.md` matches an archived copy under `openspec/changes/archive/**`
- WHEN cleanup validates the worktree
- THEN main-copy equality governs, the path is `loss`, and cleanup refuses before removal

#### Scenario: Verification uses the documented handoff layout

- GIVEN a scripted repository fixture contains `ready-for-odd/2026-09-15-worktree-workflow` and no bare `ready-for-odd/worktree-workflow` directory
- WHEN the cleanup verification runs with slug `worktree-workflow`
- THEN the evidence checks the date-prefixed path and demonstrates the required archive or explicit refusal outcome, rather than passing from a bare-slug fixture

#### Scenario: Discovery reports registered worktrees

- GIVEN sibling worktrees with free-form names
- WHEN lifecycle discovery runs
- THEN it reports exactly `git worktree list` entries, without parent-directory globbing

### Requirement: Main refreshes Graphify after merges

Graphify MUST refresh exactly once on main after a completed change from branch `odd/<slug>` is merged into main; archive MUST NOT refresh it.

#### Scenario: Merged changes refresh the authoritative graph

- GIVEN a completed change from branch `odd/<slug>` has been merged into main
- WHEN lifecycle processing completes and an unrelated PR merge is processed
- THEN the authoritative graph on main is refreshed exactly once for the completed change, the unrelated merge does not refresh it, and each worktree retains its creation-time snapshot

#### Scenario: Archive does not refresh Graphify

- GIVEN archive runs inside a worktree
- WHEN archive completes
- THEN it does not invoke `graphify . --update`; verification checks the archive trace and confirms refresh remains owned by delivery/cleanup
