# Worktree Provisioning Specification

## Requirements

### Requirement: Complete branch-scoped provisioning

The system MUST provision from `origin/main`, unset upstream, and create branch-scoped state plus only approved shared files.

#### Scenario: Fresh worktree is runnable

- GIVEN authorized entry and synchronized `origin/main`
- WHEN provisioning completes
- THEN sibling worktree `Cortex-odd-<slug>` exists on branch `odd/<slug>` with no upstream
- AND it has the immutable graph snapshot, dependencies, copied `.opencode` manifests/lockfiles, generated commands/registry, relative skill links, `.env.local` and `projects.txt` links, and a marker

#### Scenario: Provisioning does not inherit main-only paths

- GIVEN a provisioned worktree
- WHEN `git worktree list`, branch config, and link targets are inspected
- THEN dependencies and skills resolve inside it, only the two approved files resolve to main, and the upstream lookup is empty

### Requirement: Safe provisioning path

Provisioning MUST NOT use the unchanged `cortex-init.sh` path because it rewrites tracked `.opencode/opencode.json` with absolute paths and reinjects `--project-dir`.

#### Scenario: Tracked configuration remains branch-correct

- GIVEN a newly provisioned worktree
- WHEN `git diff --check` and `git status --short` run
- THEN tracked `.opencode/opencode.json` has no main absolute-path rewrite and only intentional local artifacts appear
