# Design: Auto-Resolve Superseded Cleanup Artifacts

## Technical Approach

Keep lifecycle policy in `cli/src/engine/worktree.ts` and reporting at the Commander boundary in `cli/src/commands/worktree.ts`. Filter disposable paths, apply the main-copy rule, then partition protected paths into archived `openspec` copies and losses before mutation. Retain `sameContent()` as the byte-and-recursive equality predicate.

Graphify community **Git Worktree Lifecycle** identifies `cleanupWorktree()`, `protectedUntrackedPaths()`, `sameContent()`, `CleanupRefusalError`, `worktreeCommand()`, and `output()`. Consulted edges: `worktreeCommand() → cleanupWorktree()`, `cleanupWorktree() → protectedUntrackedPaths() → sameContent()`, `cleanupWorktree() → git()`, and `CleanupRefusalError → .constructor()`. **Worktree Lifecycle Specs** is the contract source.

## Architecture Decisions

| Decision | Alternatives considered | Rationale |
|---|---|---|
| Use `hasArchivedTwin(protectedPath: string, main: string): boolean` with root `join(main, 'openspec', 'changes', 'archive')` | Hash/object lookup; broader archive roots | Enumerate every descendant under exactly that root; return true only when `sameContent(protectedPath, candidate)` succeeds, including type and complete directory entries. |
| Partition per path | Resolve or refuse the whole tree | `protectedUntrackedPaths()` changes from `string[]` to `{ preservedPaths: string[]; lossPaths: string[] }`. Only `openspec` paths use archive matching; `.cortex-sessions` continues its existing main-copy equality rule. |
| Report resolution explicitly | Silent proceed; acknowledgement flag | A resolved path is reported as `superseded/preserved`, while unresolved paths remain `loss`. An acknowledgement flag adds a human step after canonical preservation and is therefore rejected. |
| Compare against any canonical archive entry | Compare only the newest canonical change | Any dated archive may contain the preserved bytes, including nested paths. Newest-only comparison requires delta semantics and misses valid archived-delta-shaped preservation. |
| Keep validation before destructive commands | Remove then recover/copy | `cleanupWorktree()` currently validates at line 224, throws at line 225, and only then calls `archiveHandoff()` (226) and `git(... worktree remove --force ...)` (227). The new partition must preserve that ordering; `CleanupRefusalError.paths` names every `lossPaths` entry. |
| Keep provisioning rollback report-silent | Print cleanup resolution while unwinding provision failure | `create()` at `cli/src/commands/worktree.ts:30` deliberately discards `CleanupReport`: rollback needs side effects, not cleanup UX. Resolution reporting applies only to explicit cleanup; error composition at lines 31–34 is unchanged. |

## Data Flow

```text
git ls-files --others → disposable filter → main-copy check
                                      └→ openspec archive scan
                                           ├─ preserved: superseded/preserved
                                           └─ loss: CleanupRefusalError
preserved + no loss → report → handoff archive → worktree remove → success JSON
```

Archive enumeration failures, vanished/unreadable entries, type mismatches, and non-canonical bytes produce `loss`; they never silently resolve. The direct stdlib scan is O(P×A), where P is protected OpenSpec paths and A is archived entries; stop each path at its first match. No cache, index, hash pre-check, or size optimization is justified by this bounded scope.

## File Changes

| File | Action | Description |
|---|---|---|
| `cli/src/engine/worktree.ts` | Modify | Add archive predicate, return preserved/loss partition, carry preserved paths on refusal, and return a cleanup report after validation succeeds. |
| `cli/src/commands/worktree.ts` | Modify | Print `superseded/preserved` paths before success; on refusal print resolved paths before rethrowing. |

## Interfaces / Contracts

```ts
interface CleanupReport { preservedPaths: string[] }
interface ProtectedUntrackedPaths { preservedPaths: string[]; lossPaths: string[] }
cleanupWorktree(slug: string, root: string, remote: boolean): CleanupReport;
```

Successful cleanup prints sorted `superseded/preserved: <repository-relative path>` lines, then exactly the existing `{"cleaned":true,"slug":"<slug>"}` JSON line. Refusal prints resolved lines to stderr, then names all `lossPaths`; it exits non-zero with no success JSON. `.cortex-sessions/**` never enters archive resolution, and disposable provisioned paths remain unprotected.

The `create()` rollback intentionally ignores `CleanupReport` and prints no resolution lines. `createWorktree()` starts a fresh `origin/main` branch; `provisionWorktree()` adds only disposable or ignored state, so normal rollback has no protected paths. An external protected path still refuses, preserving nested cleanup-error composition and original-error rethrow.

## Testing Strategy

No test harness is added. RED/manual scenarios cover exact/recursive matches, nested dated archives, mixed preserved/loss trees, non-canonical and unreadable/vanished entries, session non-matches, disposable paths, and refusal before removal. Verify with `npm run typecheck`, `npm run build`, `git diff --check`, `gga run`, and scripted `/tmp/opencode/` repositories.

## Threat Matrix

| Boundary | Applicability | Safe/failure behavior and RED verification |
|---|---|---|
| Documentation-like paths | Applicable — `openspec` classification at `cli/src/engine/worktree.ts:91-97` controls archive protection | Safe: normalized matches under the exact root report `superseded/preserved`. Failure: unmatched, non-canonical, unreadable, vanished, or wrong-type content remains `loss` and refuses before removal. RED covers exact, recursive, nested-dated, mixed, and non-canonical OpenSpec cases; disposable/non-OpenSpec documentation remains unprotected. |
| Git repository selection | Applicable | Resolve main canonically; wrong roots and non-main starts refuse. |
| Commit state | Applicable | Inspect untracked state; loss refuses before removal. |
| Push state | Applicable | `--remote` deletes only `sdd/<slug>` after validation; no push to main. |
| PR commands | N/A — no PR automation changes | None. |

## Migration / Rollout

No migration required. Existing archives are read in place; unresolved artifacts retain conservative refusal behavior.

## Open Questions

None.
