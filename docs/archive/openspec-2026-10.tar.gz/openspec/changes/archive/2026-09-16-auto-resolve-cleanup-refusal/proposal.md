# Proposal: Auto-Resolve Superseded Cleanup Artifacts

## Intent

Make cleanup conform to the existing worktree-lifecycle requirement: refuse only when an untracked artifact is the only copy. A stale `openspec/**` file preserved byte-for-byte in main's archive is not data loss and must not block cleanup.

## Scope

### In Scope
- Compare untracked `openspec/**` paths with files/directories under `main/openspec/changes/archive/**` using recursive byte equality.
- Auto-resolve matching paths per path, report them explicitly as superseded/preserved, and continue protecting all unresolved paths.
- Preserve refusal-before-removal, complete path reporting, and existing handoff/cleanup behavior.

### Out of Scope
- Acknowledgement flags, blob/hash-object lookup, or broad archive locations.
- Auto-resolution for `.cortex-sessions/**`; its `archived/**` tree is handoff storage, not a canonical twin for arbitrary session state.
- Changes to provisioning or other worktree capabilities.

## Capabilities

### New Capabilities
- None

### Modified Capabilities
- `worktree-lifecycle`: cleanup distinguishes archived, superseded OpenSpec copies from artifacts that would actually be lost.

## Approach

Extend the existing `sameContent()` predicate. For each protected `openspec` path, walk exactly `main/openspec/changes/archive/**` and accept it only when an archived file or recursively identical directory exists; otherwise retain refusal. Apply this per path, so mixed trees proceed only when every protected path resolves. Half-written, hand-edited, or never-canonical content still refuses. Nested paths may match archives under any dated change. Directory matches require complete recursive equality; partial preservation reports each unresolved repository-relative path from Git. The archive walk is O(P×A), acceptable at repository scale. Keep `.cortex-sessions/**` governed by current main-copy equality.

The output must distinguish auto-resolved `superseded/preserved` paths from refused `loss` paths. Cleanup must validate all paths before invoking `git worktree remove --force`.

Rejected: an acknowledgement flag still requires a human after supersession; newest-canonical comparison is narrower, requires delta semantics, and misses archived-delta-shaped preservation.

## Affected Areas

| Area | Impact | Description |
|------|--------|-------------|
| `cli/src/engine/worktree.ts` | Modified | Archive-aware protection and explicit cleanup reporting. |
| `openspec/specs/worktree-lifecycle/spec.md` | Modified | Clarify archived supersession scenarios and per-path safety. |

## Risks

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| False archive match | Low | Require recursive `sameContent()` equality and exact OpenSpec archive root. |
| Open archive growth increases cleanup cost | Low | Bound scan to the archive tree; O(P×A). |

## Rollback Plan

Revert the implementation and lifecycle delta; the prior refusal behavior remains conservative and no removal occurs before validation.

## Dependencies

- Main worktree filesystem, including the untracked OpenSpec archive.

## Success Criteria

- [ ] Archived byte-identical OpenSpec copies auto-resolve with explicit supersession/preservation output.
- [ ] Non-canonical or unmatched paths still refuse non-zero before removal and are fully named.
- [ ] Typecheck, build, `git diff --check`, `gga run`, and real scenarios pass.
