# Tasks: Auto-Resolve Superseded Cleanup Artifacts

## Review Workload Forecast

| Slice | Estimated changed lines |
|---|---:|
| 1. RED fixtures and lifecycle implementation | 70–110 |
| 2. Command reporting and verification evidence | 35–60 |
| **Total** | **105–170** |

Decision needed before apply: No
Chained PRs recommended: No
Chain strategy: stacked-to-main
400-line budget risk: Low

### Suggested Work Units

| Unit | Goal | Likely PR | Focused test command | Runtime harness | Rollback boundary |
|---|---|---|---|---|---|
| 1 | Make archived OpenSpec copies resolve while losses still block cleanup | PR 1 | `npm run typecheck` | Dated throwaway repositories in an isolated harness outside the repository; run cleanup scenarios and `gga run` | Revert `cli/src/engine/worktree.ts` and `cli/src/commands/worktree.ts` |

## Phase 1: RED Manual Checks / Fixtures

- [x] 1.1 **RED:** Create dated fixtures only at `ready-for-sdd/YYYY-MM-DD-<slug>` (never `ready-for-sdd/<slug>`); record pre-fix cleanup behavior for exact archived `openspec/changes/demo/spec.md`, including stale `openspec/specs/**` content byte-identical to `main/openspec/changes/archive/YYYY-MM-DD-demo/**`, which currently refuses.
- [x] 1.2 **RED:** In dated fixtures, exercise recursive directories, nested paths matching any dated archive, mixed archived/unmatched paths, non-canonical edits, unreadable/vanished/type-mismatched entries, and only-copy refusal; record every repository-relative path and confirm no removal on loss.
- [x] 1.3 **RED:** Exercise applicable boundary cases before production changes: relative/absolute/wrong-root/non-repository and non-main starts refuse; staged/empty/disposable (`node_modules/**`, `graphify-out/**`, `.opencode/**`, `.atl/**`, `.cortex/**`) state is distinguished; `.cortex-sessions/**` archive matches still refuse under main-copy equality; `--remote` deletes only `sdd/<slug>` and never pushes main.

## Phase 2: Engine Implementation

- [x] 2.1 In `cli/src/engine/worktree.ts`, add `hasArchivedTwin()` rooted exactly at `main/openspec/changes/archive`; enumerate archive descendants and accept only byte-and-recursive `sameContent()` matches, including nested paths and safe failure on unreadable entries.
- [x] 2.2 Change `protectedUntrackedPaths()` to return `{ preservedPaths, lossPaths }`; preserve candidate exclusion, disposable filtering, main-copy equality, and `.cortex-sessions/**` behavior while partitioning only protected OpenSpec paths.
- [x] 2.3 Update `cleanupWorktree()` to return `CleanupReport`, carry preserved paths on refusal, name every loss path in `CleanupRefusalError`, and validate the complete partition before `archiveHandoff()` or `git worktree remove --force`.

## Phase 3: Command Boundary / Regression Checks

- [x] 3.1 In `cli/src/commands/worktree.ts`, print sorted `superseded/preserved:` lines before the existing success JSON; on refusal print resolved lines then rethrow, while `create()` rollback remains report-silent and keeps error composition unchanged.
- [x] 3.2 Re-run dated scenarios to prove exact/recursive/nested archive matches clean, mixed trees report both outcomes and refuse, unmatched/non-canonical/session-only copies refuse, and successful cleanup emits exactly one success JSON line.
- [x] 3.3 Report every loss path explicitly with a `loss:` label at the command boundary in `cli/src/commands/worktree.ts` on refusal, so the delta spec scenario `Resolution is explicit` is satisfied literally alongside the existing `superseded/preserved` reporting. Refusal MUST still exit non-zero, name every loss path, and print no `{"cleaned":true}`.

## Phase 4: Verification Gate

- [x] 4.1 Run `npm run typecheck`, `npm run build`, `git diff --check`, and `gga run`; run scripted real repositories in an isolated throwaway harness outside the repository and record outputs. Do not add tests, a runner, or lint; note that `npm test` exits 1 with `No test files found`.

## Verification Harness

Work-unit edit scope is the project only: `cli/src/engine/worktree.ts` and `cli/src/commands/worktree.ts`.

The RED and verification scenarios need scripted repositories that MUST NOT exist inside the worktree, because anything left there becomes an untracked artifact of the change. The harness therefore creates disposable throwaway git repositories in the system temporary directory (/tmp/opencode), builds each fixture from scratch per run, and discards it afterwards. It reads and writes no project file, leaves no tracked or untracked content in the repository, and its output is evidence only — never part of the change candidate.

## Work Unit Evidence

| Evidence | Result |
|---|---|
| Focused test command and exact result | `npm run typecheck` from `cli/`: exit 0 (`tsc --noEmit`); `npm run build`: exit 0 (esbuild output generated); `git diff --check`: exit 0; no test harness or lint script exists. |
| Runtime harness command/scenario and exact result | `CLI=.../cli/dist/index.js node <<'NODE' ... NODE` created and removed dated repositories under `/tmp/opencode/cleanup-refusal-evidence`: exact archive twin `exit=0, preserved=1, loss=0, success_json=true, removal=true`; recursive twin `exit=0, preserved=2, loss=0, success_json=true, removal=true`; nested match under a different dated archive `exit=0, preserved=1, loss=0, success_json=true, removal=true`; mixed preserved/loss `exit=1, preserved=1, loss=1, success_json=false, removal=false`; unmatched/non-canonical `exit=1, preserved=0, loss=1, success_json=false, removal=false`; `.cortex-sessions/**` archive match `exit=1, preserved=0, loss=1, success_json=false, removal=false`; disposable paths `exit=0, preserved=0, loss=0, success_json=true, removal=true`; only-copy/refusal-before-removal with two paths `exit=1, preserved=0, loss=2, success_json=false, removal=false`. |
| Review gate command and exact result | `gga run` from the worktree root: exit 0; output reported `Rules file: AGENTS.md`, `No matching files staged for commit`, and `GGA_EXIT=0`. |
| Rollback boundary | Revert `cli/src/commands/worktree.ts`, `cli/src/engine/worktree.ts`, and this change's OpenSpec artifacts; the corrective behavior is limited to refusal reporting and its evidence. |

The runtime harness was disposable and external to the repository, as required by the Verification Harness section. `npm test` remains intentionally non-viable and exits 1 with `No test files found`.
