# Tasks: Cleanup Resolves the Real Session Handoff

## Review Workload Forecast

| Slice | Estimated changed lines |
|---|---:|
| 1. Cleanup resolution and refusal safety | 180–260 |
| **Total** | **180–260** |

Decision needed before apply: No
Chained PRs recommended: No
Chain strategy: stacked-to-main
400-line budget risk: Low

### Suggested Work Units

| Unit | Goal | Likely PR | Focused test command | Runtime harness | Rollback boundary |
|---|---|---|---|---|---|
| 1 | Resolve dated handoffs and refuse destructive cleanup | PR 1 | `npm run typecheck`; `git diff --check` | Temporary repos under `/tmp/opencode/`: run cleanup scenarios and `gga run` | Revert `cli/src/engine/worktree.ts` and any required command-boundary change |

## Phase 1: RED Manual Checks / Fixtures

- [x] 1.1 **RED:** In a fixture containing `ready-for-sdd/2026-09-15-worktree-workflow` and no bare `ready-for-sdd/worktree-workflow`, run `cortex worktree cleanup worktree-workflow`; record the real pre-fix result: exit `0`, `{"cleaned":true,"slug":"worktree-workflow"}`, no archive, and the dated handoff still present (also record `git worktree list` and both path checks).
- [x] 1.2 **RED:** In a separate fixture with only an untracked `openspec/` copy, run cleanup; record the real `git worktree remove --force` result (exit `0`, no stdout) and confirm `test ! -e <worktree>/openspec`; every fixture MUST use the dated layout and MUST NOT create the bare slug directory.
- [x] 1.3 **RED:** Exercise applicable threat cases before production changes: relative/absolute/wrong-root repositories and non-repositories reject; empty/staged/disposable state is distinguished from protected untracked artifacts; `--remote` deletes only `origin/sdd/<slug>` and never pushes main. Record commands and outputs.

## Phase 2: Engine Implementation

- [x] 2.1 In `cli/src/engine/worktree.ts`, resolve directory candidates only under target and main `.cortex-sessions/ready-for-sdd`, matching `^\d{4}-\d{2}-\d{2}-${slug}$`; make zero candidates normal and refuse ambiguity with every path.
- [x] 2.2 Add atomic, idempotent archive convergence with `cortex-session`: preserve one dated destination, handle already-consumed archives, and refuse differing concurrent content without mutation.
- [x] 2.3 Add protected-only-copy detection for untracked non-ignored `openspec/**` and unresolved `.cortex-sessions/**`, exempting `node_modules/**`, `graphify-out/**`, `.opencode/**`, `.atl/**`, `.cortex/**`, and linked environment files; throw `CleanupRefusalError` with repository-relative paths before removal.

## Phase 3: Command Boundary / Regression Checks

- [x] 3.1 In `cli/src/commands/worktree.ts`, ensure refusal emits no `{"cleaned":true}` and names paths; confirm `cli/src/index.ts` already returns non-zero through top-level handling, changing it only if verification proves necessary.
- [x] 3.2 Verify exactly one candidate archives, no candidate cleans normally, two candidates refuse and mutate nothing, protected `openspec/` refuses, disposable content cleans, and equivalent main `openspec/` permits cleanup.
- [x] 3.3 Re-check registry-only discovery, main-worktree requirement, `--force` and `branch -D` justification, `--remote` semantics, and never pushing main.

## Phase 4: Verification Gate

- [x] 4.1 Run `npm run typecheck`, `npm run build`, `git diff --check`, and `gga run` through normal hooks. State that `npm test` exits 1 with `No test files found`; add no tests or lint script.
