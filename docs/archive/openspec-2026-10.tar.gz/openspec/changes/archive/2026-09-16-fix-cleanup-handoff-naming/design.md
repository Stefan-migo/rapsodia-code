# Design: Cleanup Resolves the Real Session Handoff

## Technical Approach

Keep lifecycle orchestration in `cli/src/engine/worktree.ts` and the Commander boundary in `cli/src/commands/worktree.ts`. Cleanup resolves the handoff, validates protected untracked artifacts, then archives/removes/references. Registry discovery, the main-worktree guard, force removal, optional remote deletion, and explicit Graphify refresh ownership remain unchanged.

Graphify consulted live nodes `worktreeCommand()`, `cleanupWorktree()`, `worktreePath()`, `listWorktrees()`, `refreshMainAfterMerge()`, `repositoryRoot()`, `isMainWorktree()`, and `git()`. Edges: `worktreeCommand() → cleanupWorktree()`, `cleanupWorktree() → repositoryRoot()/isMainWorktree()/worktreePath()/git()`, `listWorktrees() → git()`, and `refreshMainAfterMerge() → git()`. `GRAPH_REPORT.md` is stale (2026-06-05); live `graph.json` was used.

## Architecture Decisions

| Decision | Alternatives considered | Rationale |
|---|---|---|
| Resolve candidates across target and main `ready-for-sdd` roots | Bare slug; first match; parent scanning | The contract is `YYYY-MM-DD-<slug>`; both locations matter because inbox consumption may precede cleanup. First/loose matches can archive the wrong record. |
| Treat only change-record paths as protected | Refuse on every untracked file; preserve the entire worktree | Provisioning creates disposable `node_modules/**`, `graphify-out/**`, `.opencode/**`, `.atl/**`, and `.cortex/**`. Protecting `openspec/**` and unresolved `.cortex-sessions/**` prevents record loss without disabling cleanup. |
| Refuse before removal on protected-only-copy artifacts | Copy arbitrary files elsewhere | Refusal is lossless and deterministic; cleanup cannot claim success after discarding data. |
| Use a typed refusal error and existing top-level catch | Print success plus warning; alter global error handling | `CleanupRefusalError` carries offending paths; the action emits no success payload and `index.ts` produces a non-zero exit. |

## Data Flow

```text
slug → registered target → date-prefixed directory candidates
                         ├─ 0: no-op archive branch
                         ├─ 1: atomic archive-or-idempotent confirmation
                         └─ >1: typed refusal, no mutation
                         ↓
           protected-artifact check → worktree remove --force → branch -D
                                                        └─ --remote: push origin --delete sdd/<slug>
```

Candidates must be directories whose basename matches `^\d{4}-\d{2}-\d{2}-${slug}$`, with the already validated lowercase slug. Search only `target/.cortex-sessions/ready-for-sdd` and `main/.cortex-sessions/ready-for-sdd`; never recurse or accept files. More than one path, including the same basename in both roots, is ambiguous and names every candidate.

No candidate is normal: continue to safety validation and cleanup, without throwing or fabricating an archive. If `main/archived/<dated-name>` exists, cleanup treats the handoff as consumed and does nothing. Otherwise copy the sole source to a unique sibling temp directory, rename temp to the absent archive destination, then remove the source. If the destination exists concurrently, verify equivalent contents and remove only the source; differing content refuses. This converges session-close consumption and cleanup on one archive.

An untracked-only-copy artifact is an untracked, non-ignored path under `openspec/**` (or unresolved `.cortex-sessions/**`) with no equivalent in main and no tracked target copy. Ignore `node_modules/**`, `graphify-out/**`, `.opencode/**`, `.atl/**`, `.cortex/**`, and linked environment files: provisioning creates them and they are reproducible/local state. Report repository-relative paths and refuse before `worktree remove --force`.

## File Changes

| File | Action | Description |
|---|---|---|
| `cli/src/engine/worktree.ts` | Modify | Date-prefixed candidate resolution, idempotent atomic archive, protected-artifact check, typed refusals. |
| `cli/src/commands/worktree.ts` | Modify if required | Preserve Commander error propagation and prevent cleanup success output on refusal. |

## Interfaces / Contracts

```ts
export class CleanupRefusalError extends Error { readonly paths: string[] }
export function cleanupWorktree(slug: string, root: string, remote: boolean): void;
```

The function signature remains stable; ambiguity and data-loss prevention throw `CleanupRefusalError`. Existing `--remote` semantics, `branch -D` (required for squash-merged non-ancestor branches), `--force`, registry-only discovery, main-only cleanup, and no push to main remain contractual.

## Testing Strategy

No tests will be added: `npm test` exits 1 because no test files exist and no lint script exists. Run `npm run typecheck`, `git diff --check`, and scripted repositories under `/tmp/opencode/`. Fixtures MUST contain `ready-for-sdd/2026-09-15-worktree-workflow` and no bare slug. Exercise: one candidate archives; none cleans; two candidates exit non-zero naming both and mutate nothing; an untracked-only `openspec/` copy refuses naming paths; disposable `node_modules`, `graphify-out`, and `.opencode` content still cleans. Recheck registry-only listing, main-worktree requirement, `--remote`, force/`branch -D`, and no main push.

## Threat Matrix

| Boundary | Applicability | Design response | Planned manual verification |
|---|---|---|---|
| Documentation-like paths | N/A — no executable-file classification | No classification changes. | None |
| Git repository selection | Applicable | Canonical `repositoryRoot`, `git -C`, main-only cleanup; reject wrong/non-repositories. | Relative, absolute, wrong-root fixtures. |
| Commit state | Applicable | Inspect tracked/untracked state before destructive removal; empty/disposable state passes, protected-only-copy refuses. | Empty, staged, and untracked artifact fixtures. |
| Push state | Applicable | Delete only `sdd/<slug>` remotely when `--remote`; never push main. | Run with and without `--remote`, inspect refs/trace. |
| PR commands | N/A — no PR automation changes | Existing delivery owns PR confirmation. | None |

## Migration / Rollout

No migration required. Existing ready handoffs are consumed by the dated-directory rule; an ambiguous or protected case remains in place for operator resolution.

## Open Questions

None. No maintainer ruling is required; the delta spec and documented session convention determine the behavior.
