# Delta for Worktree Lifecycle

## MODIFIED Requirements

### Requirement: Sessions are durable and discoverable

The system MUST track `.cortex-sessions/`, allow sessions-only commits in main, and discover worktrees from Git's registry, not parent globbing. Cleanup MUST resolve matching session handoffs using the documented `YYYY-MM-DD-<slug>` convention. With exactly one matching handoff, it MUST archive that exact handoff; with no matching handoff, it MUST proceed normally because absence is not a failure; with multiple matches, it MUST refuse, exit non-zero, name every candidate, and remove neither the worktree nor any handoff. The archive move MUST be idempotent and MUST produce the same single archived handoff whether performed by `cortex-session` when it consumes the inbox at change creation or by `cortex worktree cleanup` at the end; it MUST NOT archive twice, duplicate, or lose the handoff. Cleanup MUST preserve untracked change artifacts that are their only copy, or refuse before removal with an explicit message naming the artifacts that would be lost.
(Previously: Cleanup used an unresolved bare-slug lookup and treated handoff handling, ambiguity, and untracked-only artifacts incompletely; it now resolves date-prefixed handoffs, treats absence as normal, and guarantees one idempotent archive destination.)

#### Scenario: Session record survives cleanup

- GIVEN a completed session with a tracked record and handoff `ready-for-sdd/2026-09-15-worktree-workflow`
- WHEN cleanup runs for slug `worktree-workflow` and its local and remote branches are removed
- THEN the record remains versioned, that exact handoff moves to `archived/2026-09-15-worktree-workflow`, and `git worktree list` omits the worktree

#### Scenario: Cleanup refuses an ambiguous handoff

- GIVEN more than one `ready-for-sdd/YYYY-MM-DD-worktree-workflow` candidate exists
- WHEN cleanup runs for slug `worktree-workflow`
- THEN it exits non-zero, reports that the handoff is ambiguous and names every candidate, and removes neither the worktree nor any handoff

#### Scenario: Cleanup does not destroy an untracked only copy

- GIVEN the worktree contains an untracked change artifact such as `openspec/` and main has no other copy
- WHEN cleanup would remove that worktree
- THEN the artifact remains accessible; if cleanup refuses, it exits non-zero and names the artifact before removal, and if cleanup succeeds, the artifact is preserved outside the removed worktree

#### Scenario: Verification uses the documented handoff layout

- GIVEN a scripted repository fixture contains `ready-for-sdd/2026-09-15-worktree-workflow` and no bare `ready-for-sdd/worktree-workflow` directory
- WHEN the cleanup verification runs with slug `worktree-workflow`
- THEN the evidence checks the date-prefixed path and demonstrates the required archive or explicit refusal outcome, rather than passing from a bare-slug fixture
