```yaml
schema: gentle-ai.verify-result/v1
evidence_revision: sha256:15190130ce15428938100a43fc2c67897f72a0346f0db471db7357b83464294f
verdict: pass_with_warnings
blockers: 0
critical_findings: 0
requirements: 1/1
scenarios: 4/4
test_command: npm run typecheck
test_exit_code: 0
test_output_hash: sha256:196f1666522eb103fb613a630ad10797af17a658e2c3bb79e4a5214a662b419a
build_command: npm run build
build_exit_code: 0
build_output_hash: sha256:e812d6f3ba1f8009df5915d846a10b0b16494150c68cad820520937cbbe4263e
```

## Verification Report

**Change**: `fix-cleanup-handoff-naming`  
**Verified commit**: `1edbcae` (`fix(worktree): resolve dated cleanup handoffs safely`)  
**Mode**: Standard  
**Skill resolution**: `paths-injected`; read `.opencode/skills/sdd/SKILL.md`, `.opencode/skills/graphify/SKILL.md`, `/home/stefan/.config/opencode/skills/_shared/sdd-phase-common.md`, and `/home/stefan/.config/opencode/skills/sdd-verify/references/report-format.md`.

### Scope and totals

The change modifies one requirement of the existing Worktree Lifecycle capability. The authoritative count was obtained with:

```sh
python3 - <<'PY'
from pathlib import Path
p=Path('openspec/changes/fix-cleanup-handoff-naming/specs')
text='\n'.join(x.read_text() for x in p.rglob('*.md'))
print('requirements=', text.count('### Requirement:'))
print('scenarios=', text.count('#### Scenario:'))
PY
```

Observed output:

```text
requirements= 1
scenarios= 4
```

Boundary checks:

```sh
git show --stat --oneline 1edbcae
git diff --stat 3f1d709..HEAD
```

Both reported exactly `cli/src/engine/worktree.ts`, `83 insertions(+), 20 deletions(-)` (103 changed lines), with no other candidate file. `git status --short` reported only the untracked `openspec/` canonical change artifacts before this report was written.

### Completeness

| Metric | Value |
|---|---:|
| Tasks total | 10 |
| Tasks complete | 10 |
| Tasks incomplete | 0 |

### Build, tests, and static checks

**Typecheck** — exit `0`:

```text
> cortex-brain@1.0.0 typecheck
> tsc --noEmit
```

**Build** — exit `0`:

```text
> cortex-brain@1.0.0 build
> node esbuild.config.js

Template copied: /home/stefan/Cortex-sdd-fix-cleanup-handoff-naming/cli/src/template → /home/stefan/Cortex-sdd-fix-cleanup-handoff-naming/cli/template
```

**Diff check** — `git diff --check`, exit `0`, no output.

**Automated tests** — `npm test`, exit `1`:

```text
> cortex-brain@1.0.0 test
> vitest run

 RUN  v1.6.1 /home/stefan/Cortex-sdd-fix-cleanup-handoff-naming/cli

include: **/*.{test,spec}.?(c|m)[jt]s?(x)
exclude:  **/node_modules/**, **/dist/**, **/cypress/**, **/.{idea,git,cache,output,temp}/**, **/{karma,rollup,webpack,vite,vitest,jest,ava,babel,nyc,cypress,tsup,build,eslint,prettier}.config.*
watch exclude:  **/node_modules/**, **/dist/**

No test files found, exiting with code 1
```

No tests or lint script were added. Coverage is not available. The runtime CLI scenarios below are the independent behavioral evidence.

### Spec compliance matrix

| Requirement | Scenario | Real CLI evidence | Result |
|---|---|---|---|
| Sessions are durable and discoverable | Session record survives cleanup | `node cli/dist/index.js worktree cleanup worktree-workflow --root /tmp/opencode/verify-cleanup-handoff/one` exited `0`; stdout was `{"cleaned":true,"slug":"worktree-workflow"}`. Checks showed only main in `git worktree list`, `archive_exists=0`, `ready_absent=0`, `target_absent=0`; status showed the original tracked report deletion and `?? .cortex-sessions/archived/`. The source was `ready-for-sdd/2026-09-15-worktree-workflow`; no bare directory was created. | PASS |
| Sessions are durable and discoverable | Cleanup refuses an ambiguous handoff | `node cli/dist/index.js worktree cleanup worktree-workflow --root /tmp/opencode/verify-cleanup-handoff/ambiguous` exited `1`; stdout was empty; stderr was `Ambiguous session handoff; refusing cleanup: ../ambiguous-sdd-worktree-workflow/.cortex-sessions/ready-for-sdd/2026-09-15-worktree-workflow, ../ambiguous-sdd-worktree-workflow/.cortex-sessions/ready-for-sdd/2026-09-16-worktree-workflow`. The target, both dated candidates, and registry entry remained present. | PASS |
| Sessions are durable and discoverable | Cleanup does not destroy an untracked only copy | `node cli/dist/index.js worktree cleanup worktree-workflow --root /tmp/opencode/verify-cleanup-handoff/protected` exited `1`; stdout was empty; stderr was `Refusing cleanup because untracked artifacts would be lost: openspec/change.md`. The target and `openspec/change.md` remained present. | PASS |
| Sessions are durable and discoverable | Verification uses documented handoff layout | All handoff fixtures used dated names, including `2026-09-15-worktree-workflow`; the explicit check `test ! -e .../ready-for-sdd/worktree-workflow` returned `0`. The dated target-source fixture archived successfully with exit `0`; no bare-slug fixture enabled any result. | PASS |

Additional required behavior, not a separate declared scenario:

| Behavior | Real CLI evidence | Result |
|---|---|---|
| No candidate is normal | `node cli/dist/index.js worktree cleanup worktree-workflow --root /tmp/opencode/verify-cleanup-handoff/none` exited `0`, stdout `{"cleaned":true,"slug":"worktree-workflow"}`; `no_archive=0`, `no_bare_fixture=0`, and only main remained in `git worktree list`. | PASS |

Refusal plumbing was verified through the real CLI and top-level `cli/src/index.ts`: both refusal commands had exit `1`, empty stdout, no `cleaned:true` payload, and repository-relative offending paths in stderr. No change to `cli/src/commands/worktree.ts` was required.

### Regression checks

| Contract | Evidence | Result |
|---|---|---|
| Registry-only discovery | `node cli/dist/index.js worktree list --root /tmp/opencode/verify-cleanup-handoff/registry` returned exactly the main worktree and the registered `registry-sdd-worktree-workflow`; an unrelated free-form sibling was omitted. | PASS |
| Main-worktree requirement | Running cleanup from the target path exited `1`, stdout empty, stderr `Cleanup must start from the main worktree.` | PASS |
| Force removal and squash-safe branch deletion | Source inspection of `cli/src/engine/worktree.ts` confirmed `git worktree remove --force` and `git branch -D sdd/${slug}`. | PASS |
| Remote behavior and no main push | `--remote` exited `0`; bare remote refs afterward contained only `refs/heads/main`; the main SHA was unchanged (`main_unchanged=0`). Source inspection confirmed the only push is `git push origin --delete sdd/${slug}`. | PASS |
| Graph refresh ownership | Source/design inspection confirmed `refreshMainAfterMerge` remains separate and cleanup does not invoke it. | PASS |

### Correctness

| Requirement | Status | Notes |
|---|---|---|
| Sessions are durable and discoverable | PASS | Candidate resolution is restricted to target/main `ready-for-sdd`, requires dated directory basenames, handles zero/one/multiple candidates, protects unique untracked change artifacts, and archives before forced removal. |

### Design coherence

| Decision | Followed? | Notes |
|---|---|---|
| Resolve target and main dated handoff roots | Yes | `handoffCandidates` searches only the two documented roots and accepts directories matching the dated slug expression. |
| Protect only change-record paths | Yes | `openspec/**` and unresolved `.cortex-sessions/**` are checked; disposable generated paths are exempted by Git's standard ignore handling and path filtering. |
| Refuse before destructive removal | Yes | `CleanupRefusalError` is thrown before archive, worktree removal, branch deletion, or remote deletion. |
| Typed refusal with existing top-level catch | Yes | `index.ts` catches the rejection, prints the message, and sets exit code `1`; command output is not emitted after a rejected action. |
| Atomic/idempotent archive convergence | Yes | Existing equivalent archives consume the source; new archives use a temporary sibling and rename; differing content refuses. |

### Issues found

**CRITICAL**: None.

**WARNING**:

- The repository has no test files, so `npm test` exits `1`; behavioral confidence comes from the scripted real-CLI fixtures rather than an automated test suite.
- The archive move leaves the main worktree with a tracked deletion and an untracked archived directory until a follow-up commit; the content is preserved, but “versioned” is not immediately reflected in the index after cleanup alone.

**SUGGESTION**: Add focused automated tests in a future change if the project intentionally introduces a test harness; do not treat the current no-test result as a passing test suite.

### Verdict

**PASS WITH WARNINGS** — all 1/1 declared requirements and 4/4 declared scenarios passed with dated-layout, real-CLI evidence; typecheck, build, and diff checks passed, while the repository’s absent test harness prevents a clean automated-test verdict.
