# Proposal: Cleanup Resolves the Real Session Handoff

## Intent

`cortex worktree cleanup <slug>` cannot archive the session handoff, so the spec scenario that requires the handoff to move to `archived/` fails against the real repository layout. Fix the lookup so cleanup honours the documented session naming convention, and make it impossible for cleanup to silently destroy untracked change artifacts.

## Evidence

Both defects were found by inspecting a real repository after `worktree-workflow` shipped and archived, not by a fixture.

**1. The handoff lookup can never match.** `cleanupWorktree` derives both paths from one bare slug (`cli/src/engine/worktree.ts`):

```ts
const target = worktreePath(slug, main);                       // <parent>/<main basename>-sdd-<slug>
const handoff = join(target, '.cortex-sessions/ready-for-sdd', slug);
const mainHandoff = join(main, '.cortex-sessions/ready-for-sdd', slug);
```

The session convention is date-prefixed: `skills/cortex-session/SKILL.md:121` writes `.cortex-sessions/open/YYYY-MM-DD-<slug>/report.md`. Every real directory confirms it:

```
.cortex-sessions/ready-for-sdd/2026-09-15-worktree-workflow
.cortex-sessions/ready-for-sdd/2026-09-15-spec-kit-decommission
.cortex-sessions/archived/2026-09-10-cortex-session-lifecycle
```

No single slug satisfies both lookups. `worktree-workflow` resolves the worktree but not the handoff; `2026-09-15-worktree-workflow` resolves the handoff but points at a worktree path that does not exist. The archiving block is therefore unreachable for any real session, and both `if` branches are skipped: cleanup deletes the worktree and the branch while leaving the handoff untouched in `ready-for-sdd/`.

**2. Cleanup can destroy the only copy of the archive trail.** `cleanupWorktree` ends with `git worktree remove --force`, which deletes the whole worktree directory including untracked files. In the shipped change, the entire `openspec/` tree — the archived change plus the synced capability specs — existed **only** inside the worktree, because the standing convention kept `openspec/` untracked and `main` had no `openspec/` at all. Running cleanup would have destroyed it permanently. The design's safety net ("OpenSpec artifacts are committed on the branch before cleanup") was never in effect.

**3. Why the prior verification missed it.** The `worktree-workflow` fixture created a handoff directory named with the bare `<slug>` — exactly the name the implementation expects — and never exercised the documented `YYYY-MM-DD-<slug>` convention. The scenario passed against an input chosen by the test, not by the repository. This is a coverage gap, not a flake.

## Scope

### In Scope
- `cleanupWorktree` MUST resolve the handoff by the documented date-prefixed convention, including when more than one candidate matches, and MUST refuse to guess when the match is ambiguous.
- Cleanup MUST NOT silently discard untracked artifacts that are the only copy of a change's record: either preserve them or refuse and say what would be lost.
- Verification MUST exercise the documented `YYYY-MM-DD-<slug>` layout. A fixture that invents the name the implementation expects does not count as evidence for this scenario.

### Out of Scope
- The decision about whether OpenSpec artifacts should be tracked, ignored, or exported. This change only stops cleanup from destroying them silently.
- Re-running the deferred `cortex worktree cleanup` for `worktree-workflow`. That is a delivery step, not this change.

## Related Finding — Not This Change

`refreshMainAfterMerge` runs `graphify . --update`, which regenerated `graphify-out/graph.json` but left `graphify-out/GRAPH_REPORT.md` at its previous timestamp. `AGENTS.md` tells agents to read `GRAPH_REPORT.md` for god nodes and community structure, so the artifact the workflow actually consults stays stale after a nominally successful refresh. Graphify's own output names the remedy (`graphify cluster-only <path>`). This belongs to a Graphify-refresh ownership change, not here.

## Affected Areas

| Area | Impact | Description |
|------|--------|-------------|
| `cli/src/engine/worktree.ts` | Modified | Handoff resolution and the pre-removal safety check |
| `cli/src/commands/worktree.ts` | Possibly modified | Surfacing a refusal as a non-zero, actionable result |
| `.cortex-sessions/` layout | Consumed | The date-prefixed convention becomes the contract, not an accident |

## Risks

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| Accepting a loose name match archives the wrong session | Med | Match the documented convention exactly and refuse on ambiguity |
| Refusing to clean destroys the workflow's usefulness | Low | Refuse only when data would be lost, and name the offending paths |
| The deferred cleanup keeps slipping | Med | The `worktree-workflow` worktree stays in place until this lands |

## Rollback Plan

Revert the commit. Cleanup returns to its current behaviour, which is the state already documented as a known warning; no data is lost by reverting as long as the `worktree-workflow` worktree is still intact.

## Dependencies

The documented session convention in `skills/cortex-session/SKILL.md`, and a real date-prefixed handoff to verify against — `ready-for-sdd/2026-09-15-worktree-workflow` is present and can serve as the acceptance fixture.

## Success Criteria

- [ ] Cleanup moves `ready-for-sdd/YYYY-MM-DD-<slug>` to `archived/YYYY-MM-DD-<slug>` for a real date-prefixed handoff, proven against that exact layout.
- [ ] Cleanup refuses, with an explicit message naming the paths, when it would destroy the only copy of untracked change artifacts.
- [ ] Verification's fixture uses the documented naming convention rather than one chosen to match the implementation.
