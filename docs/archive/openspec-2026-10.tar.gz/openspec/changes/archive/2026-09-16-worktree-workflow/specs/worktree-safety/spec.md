# Worktree Safety Specification

## Requirements

### Requirement: Consent controls SDD entry

The orchestrator MUST request consent before creation, run SDD only in the accepted worktree, and stop without fallback on decline.

#### Scenario: Consent is accepted

- GIVEN a ready-for-SDD handoff in main
- WHEN the user accepts the consent gate
- THEN it provisions the sibling before the first phase and runs subsequent SDD commands there

#### Scenario: Consent is declined

- GIVEN a ready-for-SDD handoff in main
- WHEN the user declines consent
- THEN the change stops immediately; no SDD phase, worktree, or main fallback occurs
- AND `git status --short` and `git worktree list` remain unchanged

### Requirement: Main worktree protects code commits

The commit guard MUST compare `git rev-parse --git-dir` with `git rev-parse --git-common-dir`; when equal, it MUST reject direct code commits but allow commits touching only `.cortex-sessions/**`.

#### Scenario: Direct main commit is blocked but merge can land

- GIVEN the two paths are equal and staged files include anything outside `.cortex-sessions/**`
- WHEN a direct commit is attempted
- THEN the direct commit is rejected; `pre-merge-commit` remains unblocked because merges do not run `pre-commit`

### Requirement: Planning does not dirty main

`cortex start` MUST write generated prelude state only under ignored `.cortex/` and MUST NOT rewrite tracked `opencode.json`.

#### Scenario: Planning leaves tracked configuration unchanged

- GIVEN clean main
- WHEN `cortex start` completes
- THEN the prelude is under ignored `.cortex/`, tracked configuration is unchanged, and `git status --short` reports no generated state
