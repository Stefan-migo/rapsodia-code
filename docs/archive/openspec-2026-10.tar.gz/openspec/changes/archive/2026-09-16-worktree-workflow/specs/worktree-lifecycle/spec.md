# Worktree Lifecycle Specification

## Requirements

### Requirement: Sessions are durable and discoverable

The system MUST track `.cortex-sessions/`, allow sessions-only commits in main, and discover worktrees from Git's registry, not parent globbing.

#### Scenario: Session record survives cleanup

- GIVEN a completed session with a tracked record
- WHEN its sibling worktree and local and remote branches are removed
- THEN the record remains versioned, the handoff moves to `archived/`, and `git worktree list` omits it

#### Scenario: Discovery reports registered worktrees

- GIVEN sibling worktrees with free-form names
- WHEN lifecycle discovery runs
- THEN it reports exactly `git worktree list` entries, without parent-directory globbing

### Requirement: Main refreshes Graphify after merges

Graphify MUST refresh exactly once on main after a completed SDD change from branch `sdd/<slug>` is merged into main; SDD archive MUST NOT refresh it.

#### Scenario: Merged changes refresh the authoritative graph

- GIVEN a completed SDD change from branch `sdd/<slug>` has been merged into main
- WHEN lifecycle processing completes and an unrelated PR merge is processed
- THEN the authoritative graph on main is refreshed exactly once for the completed change, the unrelated merge does not refresh it, and each worktree retains its creation-time snapshot

#### Scenario: Archive does not refresh Graphify

- GIVEN archive runs inside a worktree
- WHEN archive completes
- THEN it does not invoke `graphify . --update`; verification checks the archive trace and confirms refresh remains owned by delivery/cleanup
