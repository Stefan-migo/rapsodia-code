# Design: Safe Worktree Workflow

## Technical Approach

Add one Commander `worktree` command backed by `engine/worktree.ts`. After explicit consent, the orchestrator fetches `origin/main`, creates sibling `sdd/<slug>` without an upstream, and provisions deterministic branch-local state. `startCommand()` keeps planning in main but writes only ignored `.cortex/` state; lifecycle discovery and cleanup use Git’s registry. Graphify citations: `startCommand()` calls `buildPrelude()` and `openSession()`; `context.ts` contains `buildPrelude()`; `closeCommand()` is the lifecycle command node; `initCommand()` calls `copyTemplate()`, `generateManifest()`, and `addProject()`; `findProjectRoot()` is the repository-authority node. The graph has no nodes for the new worktree module, hooks, or `cortex-init.sh`; those are new artifacts, so no names are invented.

## Architecture Decisions

| Decision | Alternatives considered | Rationale |
|---|---|---|
| Keep worktree orchestration in `engine/worktree.ts`, exposed through `commands/worktree.ts` | New shell-only workflow; scattered command handlers | Reuses Commander and `engine/deps.ts`/`template.ts` patterns while keeping Git safety in one testable boundary. |
| Provision from a manifest with relative links and an immutable `graphify-out/` copy | Invoke unchanged `cortex-init.sh`; live-link graph or skills | `cortex-init.sh` rewrites tracked config with absolute paths. A snapshot makes branch context honest; relative links keep skills branch-local. |
| Put dependency ignores in tracked root `.gitignore` | Rely on untracked/self-ignored `.opencode/.gitignore`; broad untracked-only setup | Root rules survive worktree creation and prevent `.opencode/node_modules/`, `.opencode/tools/node_modules/`, and root `node_modules/` from becoming committable. Copy the two `.opencode` manifests/lockfiles as provisioning inputs. |
| Enforce consent and main protection at both orchestrator entry and Git hook | Warn-only behavior or fallback to main | Decline must perform no filesystem/Git action; equality of `--git-dir` and `--git-common-dir` blocks code commits while allowing sessions-only commits. |

## Data Flow

```text
ready-for-sdd → consent → fetch/add → provisionWorktree()
                                      ├─ snapshot, deps, links, marker
                                      └─ commands/registry
                         ↓
                SDD phases + PR from sdd/<slug>
                         ↓ merged PR reported by delivery flow
       delivery verifies merged head + pulls main → graphify . --update
```

Git’s `post-merge` hook receives only a squash indicator and cannot reliably identify a GitHub squash merge from `sdd/<slug>`; an unrelated merge has the same local hook context. Therefore the post-merge hook is not a blanket trigger. The delivery/cleanup flow owns refresh: after GitHub confirms a merged PR whose head is `sdd/<slug>`, it records the expected merge SHA, pulls main, verifies that SHA is now `HEAD`/an ancestor, and explicitly runs `graphify . --update` from main. The hook may validate main and fail visibly, but never refreshes for an unmarked merge. Worktrees retain creation-time snapshots.

## File Changes

| File | Action | Description |
|---|---|---|
| `cli/src/commands/worktree.ts` | Create | Commander handlers: `create`, `provision`, `list`, `cleanup`; validate slug/path and print machine-readable results. |
| `cli/src/engine/worktree.ts` | Create | `createWorktree`, `provisionWorktree`, `listWorktrees`, `cleanupWorktree`, `assertNotMainWorktree`, `isMainWorktree`; use `execFileSync` with explicit args. |
| `cli/src/index.ts` | Modify | Register `cortex worktree create|provision|list|cleanup`. |
| `cli/src/commands/start.ts` | Modify | Remove `writeOpenCodeConfig` and config mutation; retain `.cortex/prelude.md` generation. |
| `.gitignore` | Modify | Ignore `.cortex/`, root and nested dependency directories; remove `/.cortex-sessions/`. |
| `.githooks/pre-commit` | Modify | Before GGA, reject main-worktree staged code unless every path is `.cortex-sessions/**`. |
| `.githooks/post-merge` and delivery/cleanup flow | Create/Modify | Do not refresh for arbitrary merges. Delivery confirms a merged GitHub PR with head `sdd/<slug>`, verifies the pulled merge SHA, then explicitly runs `graphify . --update` from main; the hook only enforces main-context safety. |
| `.opencode/skills/sdd/SKILL.md` | Modify | Document consent-before-entry, worktree-only phases, and that archive does not refresh Graphify. |
| `cortex-init.sh` | Modify | Extract reusable safe provisioning conventions; do not invoke the config-rewriting block for worktrees. |

## Interfaces / Contracts

```ts
createWorktree(slug: string, root: string): Promise<string>;
provisionWorktree(worktree: string, mainRoot: string): void;
listWorktrees(root: string): WorktreeRecord[]; // parses `git worktree list --porcelain`
cleanupWorktree(slug: string, root: string, remote: boolean): void;
```

Provisioning copies `graphify-out/`, `.opencode/package.json`, and both lockfiles; installs dependencies locally; creates relative skill links, generated `.opencode/commands/` and `.atl/skill-registry.md` using an absolute `--cwd`; links only `.env.local` and `projects.txt`; writes a marker. It MUST unset `branch.sdd/<slug>.merge` and related upstream config. Consent is an orchestrator gate before `createWorktree`; false returns immediately with no fallback.

## Testing Strategy

No test harness exists: `npm test` fails with “No test files found”; lint and coverage are unavailable. Run `npm run typecheck`, `git diff --check`, and manual shell verification in temporary repositories: start leaves tracked config clean; accepted creation has no upstream and only approved main links; decline leaves status and registry unchanged; the main hook blocks code but permits sessions-only commits; list parses registry names; cleanup archives handoff and removes refs; and delivery refreshes only after GitHub reports a merged `sdd/<slug>` PR and the expected SHA is present on main. An unrelated merge, squash indicator alone, missing marker, wrong branch, or non-main cwd must not refresh. `gga run` remains the review gate.

## Threat Matrix

| Boundary | Applicability and response | Planned manual verification |
|---|---|---|
| Documentation-like paths | N/A — no executable-file classification changes. | None |
| Git repository selection | Applicable — canonical absolute root and `git -C`; reject non-repository and main misuse. | Manually exercise relative/absolute roots and wrong repositories. |
| Commit state | Applicable — inspect staged index; empty index passes; `commit -a` code on main is rejected by hook state. | Manually stage code, sessions-only files, and nothing. |
| Push state | Applicable — cleanup uses explicit branch/ref and optional remote deletion; never pushes main. | Manually verify tracking, first-push, and explicit-refspec cases. |
| PR commands | N/A — PR creation remains existing delivery tooling, not implemented here. | None |

## Migration / Rollout

Ship three independently verifiable slices: start/ignore safety; creation/provisioning/guard; lifecycle hook/discovery/cleanup. Existing worktrees are not auto-migrated. No Spec-Kit decommissioning is included.

## Open Questions

None.
