# Tasks: Safe Worktree Workflow

## Review Workload Forecast

| Slice | Estimated changed lines |
|---|---:|
| 1. Start/ignore safety | 60–90 |
| 2. Creation/provisioning/guard | 300–380 |
| 3. Lifecycle/discovery/cleanup | 220–300 |
| **Total** | **580–770** |

Decision needed before apply: No
Chained PRs recommended: Yes
Chain strategy: stacked-to-main
400-line budget risk: High

### Proposed PR Boundaries

- **PR 1:** Slice 1 only; independent sibling PR targeting `main`.
- **PR 2:** Slice 2 only; independent sibling PR targeting `main`.
- **PR 3:** Slice 3 only; independent sibling PR targeting `main`.

### Suggested Work Units

| Unit | Goal | Likely PR | Focused test command | Runtime harness | Rollback boundary |
|---|---|---|---|---|---|
| 1 | Keep planning from dirtying main | PR 1 | `npm run typecheck`; `git diff --check` | Temporary repo: `cortex start`; inspect status | `start.ts` and `.gitignore` |
| 2 | Provision isolated worktrees safely | PR 2 | `npm run typecheck`; `gga run` | Temporary repo: consent, links, snapshot, guard | Worktree CLI, provisioning, hook, init |
| 3 | Discover, refresh, archive, clean | PR 3 | `git diff --check`; `gga run` | Temporary repo: marked merge, unrelated merge, cleanup | Lifecycle hook/skill/cleanup |

## Phase 1: Slice 1 — Start / Ignore Safety

- [x] 1.1 **RED manual check:** clean main, run `cortex start`, and record the tracked-config/status failure; fix `cli/src/commands/start.ts` to generate only ignored `.cortex/prelude.md`. Verify `git status --short` and tracked `opencode.json`.
- [x] 1.2 Update `.gitignore` for `.cortex/` and dependency directories; remove the sessions ignore. Verify `git check-ignore` and `git status --short`.

## Phase 2: Slice 2 — Creation / Provisioning / Guard

- [x] 2.1 **RED manual checks:** exercise non-repository/main misuse, declined consent, and staged main code; expect reject, no state change, and no main code commit.
- [x] 2.2 Create `cli/src/engine/worktree.ts` with canonical roots, `createWorktree`, `provisionWorktree`, upstream removal, main detection, and explicit Git args. Verify wrong roots in a temporary repo.
- [x] 2.3 Create `cli/src/commands/worktree.ts`, register it in `cli/src/index.ts`, and stop on declined consent. Verify accepted/declined status and `git worktree list`.
- [x] 2.4 Provision graph snapshot, dependencies/manifests, relative skills, generated commands/registry, approved links, and marker without unsafe `cortex-init.sh`. Verify targets, empty upstream, diff, and status.
- [x] 2.5 Refactor `cortex-init.sh` conventions and update `.githooks/pre-commit` for sessions-only main commits. Verify empty, sessions-only, and mixed indexes.

## Phase 3: Slice 3 — Lifecycle / Discovery / Cleanup

- [x] 3.1 **RED manual checks:** simulate cleanup, free-form names, unrelated merge, missing marker, wrong branch, and archive refresh; expect registry-only discovery, no main push, and no unmarked refresh.
- [x] 3.2 Implement lifecycle handlers and handoff cleanup in `cli/src/engine/worktree.ts`, `cli/src/commands/worktree.ts`; verify registry listing, archived handoff, ref removal, and tracked sessions.
- [x] 3.3 Update `.githooks/post-merge`/delivery to refresh only after confirmed merged `sdd/<slug>` SHA; remove refresh from `.opencode/skills/sdd/SKILL.md`. Verify exactly once and no unrelated/squash-only refresh.

## Verification Gate

- [x] 4.1 Run `npm run typecheck`, `git diff --check`, and `gga run`; do not claim `npm test` coverage because no test files exist.
