# Proposal: Safe Worktree Workflow

## Intent

Keep `main` converged with `origin/main` while allowing planning there and isolating every SDD lifecycle in a sibling Git worktree. This addresses the current `cortex start` main-dirtying defect and prevents unprovisioned, incorrectly linked, or directly committed implementation worktrees.

## Scope

### In Scope
- **Slice 1 — main safety:** make `cortex start` write only ignored local prelude state; stop mutating tracked `opencode.json`; add `.cortex/` to `.gitignore` and remove `/.cortex-sessions/`.
- **Slice 2 — entry and isolation:** add worktree creation, upstream unsetting, explicit orchestrator consent (decline stops), main-worktree guards, and complete provisioning: graph snapshot, dependencies, relative skill links, generated commands/registry, linked `.env.local`/`projects.txt`, and required `.opencode` package/lockfiles.
- **Slice 3 — lifecycle:** track session records with a sessions-only commit carve-out, refresh Graphify from `post-merge` on main, remove the `sdd-archive` refresh mandate, and add cleanup/discovery behavior.

### Out of Scope
- Decommissioning Spec-Kit (`.specify/`); it is a separately registered technical-debt change.
- Stacked or dependent PRs between independent changes, local merges to `main`, or live graph links from worktrees.

## Capabilities

### New Capabilities
- `worktree-provisioning`: authorized creation and branch-scoped provisioning of isolated SDD worktrees.
- `worktree-safety`: main-worktree and commit protections, upstream correctness, and orchestrator stop behavior.
- `worktree-lifecycle`: tracked sessions, post-merge graph refresh, worktree discovery, and cleanup.

### Modified Capabilities
- None; no existing OpenSpec capability specs are present.

## Approach

Implement the three slices in dependency order, reusing the Commander CLI, existing session/context engines, tracked hooks, and `cortex-init.sh` conventions while extracting safe provisioning rather than invoking its config-rewriting behavior unchanged. Preserve an immutable `graphify-out/` snapshot per worktree; refresh only after GitHub PR merges into local main. Graph validation covered `startCommand()`, `buildPrelude()`, `writeOpenCodeConfig()`, `closeCommand()`, and `findProjectRoot()` plus their config/session edges. This is expected to be large; `sdd-tasks` MUST forecast workload against the 400-line review budget and select `auto-chain` slices as needed.

## Affected Areas

| Area | Impact | Description |
|------|--------|-------------|
| `cli/src/commands`, `cli/src/engine` | Modified/New | Start safety, worktree command, lifecycle state |
| `.gitignore`, `.githooks/`, `cortex-init.sh` | Modified | Isolation, commit guard, safe provisioning |
| SDD/orchestrator skills and hooks | Modified | Consent, archive and post-merge responsibilities |

## Risks

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| Provisioning leaks main paths or secrets | High | Manifest-driven checks, relative links, explicit shared-state allowlist |
| Stale graph omits new modules | Med | Document immutable-base ceiling; refresh on merge |
| Large diff overloads review | High | Three independently verifiable slices and task-level budget forecast |

## Rollback Plan

Revert each slice independently. Remove created worktrees and generated links before deleting branches; restore the prior hook, ignore rules, CLI behavior, and archive instruction from Git history. If a merge hook misbehaves, disable only the post-merge Graphify invocation while retaining the prior graph snapshot.

## Dependencies

- Git worktree support, GitHub PR delivery, Graphify, existing Engram/SDD orchestration, and npm manifests copied into fresh worktrees.

## Success Criteria

- [ ] Planning leaves no unignored generated state or tracked config mutation in main.
- [ ] Declining consent never runs SDD in main; accepted worktrees provision and typecheck independently.
- [ ] Merged PRs refresh Graphify on main, and cleanup removes local/remote worktree state without losing tracked session records.
